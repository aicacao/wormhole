echo "Running SageMaker user profile deletion script."
for regions in `aws ec2 describe-regions --output text | awk '{print $4}'`; do
	echo "Searching user profiles in region: [$regions]..."
	SEARCH_ALL_USER_PROFILE=$(aws sagemaker list-user-profiles --region $regions --output text | awk '{print $3,$6}')
	if [ -z "$SEARCH_ALL_USER_PROFILE" ]; then
		echo "No user profiles found!"
	else
		while read domain_id user_profile_name; do
			echo "Deleting user profile {domain: [$domain_id], user_profile_name: [$user_profile_name]}"
			if DELETE_FOUND_USER_PROFILE=$(aws sagemaker delete-user-profile --region $regions --domain-id $domain_id --user-profile-name $user_profile_name --output text 2>&1); then
				echo "Successfully deleted!"
			else
				echo "Error! Read the error message below.$DELETE_FOUND_USER_PROFILE"
			fi
		done <<< "$SEARCH_ALL_USER_PROFILE"
	fi
done

echo "Finished deleting SageMaker user profiles."
