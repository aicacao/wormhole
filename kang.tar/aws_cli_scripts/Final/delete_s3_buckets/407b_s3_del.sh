echo "Running S3 buckets deletion script."
for bucket_name in $(aws s3 ls s3:// | awk '{print $3}'); do
	echo "Deleting S3 bucket: [$bucket_name]"
	if DELETE_FOUND_BUCKET=$(aws s3 rb s3://$bucket_name --force 2>&1 > /dev/null); then
		echo "Successfully deleted!"
	else
		echo -e "Error! Read the error message below.\n\n$(echo $DELETE_FOUND_BUCKET)"
	fi
done

echo -e "\nFinished deleting all S3 buckets."
