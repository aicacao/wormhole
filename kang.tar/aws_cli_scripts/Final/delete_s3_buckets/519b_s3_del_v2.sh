echo "Running S3 buckets deletion script."
EXISTING_BUCKETS=$(aws s3 ls s3:// | awk '{print $3}')
if [ -z "$EXISTING_BUCKETS" ]; then
	echo "No bucket found!"
else
	for bucket_name in $EXISTING_BUCKETS; do
		echo "Deleting S3 bucket: [$bucket_name]"
		if DELETE_FOUND_BUCKET=$(aws s3 rb s3://$bucket_name --force 2>&1 > /dev/null); then
			echo "Successfully deleted!"
		else
			echo -e "Error! Read the error message below.\n\n$(echo $DELETE_FOUND_BUCKET)"
		fi
	done
fi

echo -e "\nFinished deleting all S3 buckets."
