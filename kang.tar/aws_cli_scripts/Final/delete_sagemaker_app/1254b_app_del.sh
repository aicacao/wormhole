echo "Running SageMaker app deletion script."
for regions in $(aws ec2 describe-regions --output text | awk '{print $4}'); do
	echo "Searching apps in region: [$regions]..."
	SEARCH_ALL_APPS=$(aws sagemaker list-apps --region $regions --output text | awk '{print $2,$3,$5,$7}')
	if [ -z "$SEARCH_ALL_APPS" ]; then
		echo "No apps found!"
	else
		while read app_name app_type domain_id user_profile_name; do
			if aws sagemaker describe-app --region $regions --domain-id $domain_id --user-profile-name $user_profile_name --app-type $app_type --app-name $app_name --output text | grep -q Deleted; then
				echo "Skipping app {domain: [$domain_id], user_profile_name: [$user_profile_name], app_name: [$app_name]}. App already deleted!"
			else
				echo "Deleting app {domain: [$domain_id], user_profile_name: [$user_profile_name], app_name: [$app_name]}"
				if DELETE_FOUND_APP=$(aws sagemaker delete-app --region $regions --domain-id $domain_id --user-profile-name $user_profile_name --app-type $app_type --app-name $app_name --output text 2>&1); then
					echo "Successfully deleted!"
				else
					echo "Error! Read the error message below.$DELETE_FOUND_APP"
				fi
			fi
		done <<< "$SEARCH_ALL_APPS"
	fi
done

echo "Finished deleting SageMaker apps."
