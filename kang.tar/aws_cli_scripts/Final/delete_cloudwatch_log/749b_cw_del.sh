echo "Running CloudWatch log group deletion script."
for regions in $(aws ec2 describe-regions --output text | awk '{print $4}'); do
	echo "Searching log groups in region: [$regions]..."
	SEARCH_ALL_LOG_GROUP=$(aws logs describe-log-groups --region $regions --output text | awk '{print $4}')
	if [ -z "$SEARCH_ALL_LOG_GROUP" ]; then
		echo "No log group found!"
	else
		echo "Deleting log group {log_group_name: [$SEARCH_ALL_LOG_GROUP]}"
		if DELETE_FOUND_LOG_GROUP=$(aws logs delete-log-group --log-group-name $SEARCH_ALL_LOG_GROUP --region $regions --output text 2>&1); then
			echo "Successfully deleted!"
		else
			echo "Error! Read the error message below.$DELETE_FOUND_LOG_GROUP"
		fi
	fi
done

echo "Finished deleting CloudWatch log groups."
