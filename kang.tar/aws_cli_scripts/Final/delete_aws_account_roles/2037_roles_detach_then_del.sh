echo "Running AWS roles deletion script."
for existing_roles in $(aws iam list-roles --query 'Roles[].RoleName' --output text | tr "\t" "\n" | grep -v -e AWSServiceRoleForSupport -e AWSServiceRoleForTrustedAdvisor); do
	echo "Searching attached policy for role: [$existing_roles] ..."
	SEARCH_POLICY_ARN=$(aws iam list-attached-role-policies --role-name $existing_roles --output text | awk '{print $2}')
	if [ -z "$SEARCH_POLICY_ARN" ]; then
		echo "No attached policy found!"
		sleep 1s
		echo "Deleting role: [$existing_roles] ..."
		if READY_DELETE_ROLE=$(aws iam delete-role --role-name $existing_roles --output text 2>&1 > /dev/null); then
			echo "Successfully deleted!"
		else
			echo "Error! Read the error message below.$READY_DELETE_ROLE"
		fi
	else
		for role_policies in $SEARCH_POLICY_ARN; do
			echo "Detaching a policy in role: [$existing_roles] ..."
			if DETACH_FOUND_ROLE_POLICY=$(aws iam detach-role-policy --role-name $existing_roles --policy-arn $role_policies --output text 2>&1 > /dev/null); then
				echo "Successfully detached!"
				sleep 1s
			else
				echo $DETACH_FOUND_ROLE_POLICY | grep -q 'only modifiable by AWS' || \
				echo "Error! Read the error message below.$DETACH_FOUND_ROLE_POLICY"
			fi
		done

		sleep 5s
		echo "Deleting role: [$existing_roles] ..."
		if DELETE_ROLE=$(aws iam delete-role --role-name $existing_roles --output text 2>&1 > /dev/null); then
			echo "Successfully deleted!"
		else
			if echo $DELETE_ROLE | grep -q 'only modifiable by AWS'; then
				if DELETE_AWS_MNG_ROLE=$(aws iam delete-service-linked-role --role-name $existing_roles --output text 2>&1 > /dev/null); then
					echo "Successfully deleted!"
				else
					echo "Error! Read the error message below.$DELETE_AWS_MNG_ROLE"
				fi
			else
				echo "Error! Read the error message below.$DELETE_ROLE"
			fi
		fi
	fi
done

echo "Finished deleting AWS roles."

# aws iam list-roles --query 'Roles[?RoleName!=`AWSServiceRoleForSupport`&&RoleName!=`AWSServiceRoleForTrustedAdvisor`].RoleName' --output text | tr "\t" "\n"
