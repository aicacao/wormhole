echo "Running AWS account policies deletion script."
for existing_policies in $(aws iam list-policies --scope Local --output text | awk '{print $2}'); do
	if [ -z "$existing_policies" ]; then
		echo "No policies found!"
	else
		echo "Deleting policy: [$existing_policies] ..."
		if DELETE_FOUND_POLICY=$(aws iam delete-policy --policy-arn $existing_policies --output text 2>&1 > /dev/null); then
			echo "Successfully deleted!"
		else
			echo "Error! Read the error message below.$DELETE_FOUND_POLICY"
		fi
	fi
done

echo "Finished deleting AWS account policies."
