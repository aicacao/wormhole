echo "Running AWS account policies deletion script."
SEARCH_AWS_POLICIES=$(aws iam list-policies --scope Local --output text | awk '{print $2}')
if [ -z "$SEARCH_AWS_POLICIES" ]; then
	echo "No policies found!"
else
	for existing_policies in $SEARCH_AWS_POLICIES; do
		if DELETE_FOUND_POLICY=$(aws iam delete-policy --policy-arn $existing_policies --output text 2>&1 > /dev/null); then
			echo "Successfully deleted!"
		else
			echo "Error! Read the error message below.$DELETE_FOUND_POLICY"
		fi
	done
fi

echo "Finished deleting AWS account policies."
