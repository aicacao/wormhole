echo "Running SageMaker domain deletion script."
for regions in $(aws ec2 describe-regions --output text | awk '{print $4}'); do
	echo "Searching domains in region: [$regions]..."
	SEARCH_ALL_DOMAIN=$(aws sagemaker list-domains --region $regions --output text | awk '{print $4}')
	if [ -z "$SEARCH_ALL_DOMAIN" ]; then
		echo "No domain found!"
	else
		echo "Deleting domain {domain_id: [$SEARCH_ALL_DOMAIN]}"
		if DELETE_FOUND_DOMAIN=$(aws sagemaker delete-domain --domain-id $SEARCH_ALL_DOMAIN --region $regions --retention-policy HomeEfsFileSystem=Delete --output text 2>&1); then
			echo "Successfully deleted!"
		else
			echo "Error! Read the error message below.$DELETE_FOUND_DOMAIN"
		fi
	fi
done

echo "Finished deleting SageMaker domains."
